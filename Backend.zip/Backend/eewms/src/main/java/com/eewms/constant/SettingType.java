package com.eewms.constant;

public enum SettingType {
    UNIT,
    CATEGORY,
    BRAND
}
