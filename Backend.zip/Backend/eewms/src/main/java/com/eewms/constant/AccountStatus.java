package com.eewms.constant;

public enum AccountStatus {
    ACTIVE,
    DEACTIVE
}